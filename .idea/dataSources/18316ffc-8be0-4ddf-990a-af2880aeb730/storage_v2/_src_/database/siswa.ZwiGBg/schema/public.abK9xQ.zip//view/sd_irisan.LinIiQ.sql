create view sd_irisan as
  SELECT irisan.kecamatan,
         irisan.kelurahan,
         irisan.rw,
         irisan.rt,
         irisan.alamat,
         irisan.nik,
         irisan.nama,
         irisan.tgl,
         irisan.bulan,
         irisan.tahun,
         irisan.usia_pendataan,
         irisan.usia_saat_ini,
         irisan.kip,
         irisan.pkh
  FROM (irisan
      JOIN sd ON (((sd.nik) :: text = (irisan.nik) :: text)));

alter table sd_irisan
  owner to postgres;

