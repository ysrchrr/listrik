create view sd_bdt as
  SELECT bdt.no,
         bdt.nik,
         bdt.nama,
         bdt.tahun_lahir,
         bdt.usia,
         bdt.usia_saat_ini,
         bdt.tgl_lahir,
         bdt.sta_pkh,
         bdt.sta_kip,
         bdt.pkh,
         bdt.kip,
         bdt.kec,
         bdt.kel,
         bdt.alamat
  FROM (bdt
      JOIN sd ON (((sd.nik) :: text = (bdt.nik) :: text)));

alter table sd_bdt
  owner to postgres;

